(() => {
  const words = ['WHATEVER', 'GGCooking', 'Gameboys', 'ศิลปะล่ะ', 'รับบิน', '8ท', 'ทททททททท', 'ล้านก้าว', 'กินจิต กินใจ'];
  const normalizeText = text => String(text).normalize('NFKC').toLocaleLowerCase('en').replace(/[\s\p{P}\p{S}]+/gu, '');
  function normalizeConfig(raw = {}) {
    const keywords = Array.isArray(raw.keywords)
      ? raw.keywords.filter(item => item && typeof item.text === 'string' && normalizeText(item.text))
        .map(item => ({ text: item.text.trim(), enabled: item.enabled !== false }))
      : words.map(text => ({ text, enabled: true }));
    const videoOverrides = Object.fromEntries(Object.entries(raw.videoOverrides || {})
      .filter(([id, value]) => /^[\w-]{11}$/.test(id) && value && typeof value.enabled === 'boolean')
      .map(([id, value]) => [id, { enabled: value.enabled, title: String(value.title || '').slice(0, 300) }]));
    return { filtersEnabled: raw.filtersEnabled !== false, keywords, videoOverrides };
  }
  function decide(config, id, title) {
    const override = Object.hasOwn(config.videoOverrides, id) ? config.videoOverrides[id] : null;
    if (override) return { enabled: override.enabled, reason: 'override' };
    const keyword = config.filtersEnabled && config.keywords.find(item => item.enabled && normalizeText(title).includes(normalizeText(item.text)));
    return keyword ? { enabled: false, reason: 'keyword', keyword: keyword.text } : { enabled: true, reason: 'default' };
  }
  globalThis.RubsarbIntro = Object.freeze({ normalizeText, normalizeConfig, decide });
})();
