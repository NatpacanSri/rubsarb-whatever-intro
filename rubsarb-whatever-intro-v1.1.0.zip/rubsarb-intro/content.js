(() => {
  const CHANNEL_ID = "UCxCKl-K0sedNZp7xfWg0VTw";
  const R = RubsarbIntro;
  let config = R.normalizeConfig();
  let settingsReady = false;
  let settingsFailed = false;
  let session = null;

  function currentId() {
    return location.pathname === "/watch"
      ? new URL(location.href).searchParams.get("v") : null;
  }

  function sourceVideo() {
    return document.querySelector("#movie_player video.html5-main-video");
  }

  function hasStartOffset() {
    const url = new URL(location.href);
    const values = [url.searchParams.get("t"), url.searchParams.get("start"),
      url.searchParams.get("time_continue"), new URLSearchParams(url.hash.slice(1)).get("t")];
    return values.some(value => {
      const time = value?.match(/^(?:(\d+)h)?(?:(\d+)m)?(?:(\d+(?:\.\d+)?)s?)?$/i);
      return time && (Number(time[1] || 0) * 3600 + Number(time[2] || 0) * 60 + Number(time[3] || 0)) > 0;
    });
  }

  function showingAd() {
    const player = document.getElementById("movie_player");
    return player?.classList.contains("ad-showing") || player?.classList.contains("ad-interrupting");
  }

  function syncRoute() {
    const id = currentId();
    if (session?.id === id) return;
    if (session) {
      session.intro?.pause();
      session.host?.remove();
    }
    session = id ? {
      id, title: '', target: null, done: hasStartOffset(), wantsPlay: false,
      doneReason: hasStartOffset() ? 'offset' : null,
      startedAt: Date.now(), host: null, intro: null
    } : null;
  }

  function blocked() {
    return session && !session.done && session.target !== false && !settingsFailed && !showingAd();
  }

  function resume(s) {
    if (session !== s || currentId() !== s.id || !s.wantsPlay) return;
    sourceVideo()?.play().catch(() => {});
  }

  function finish(s, reason = 'played') {
    if (session !== s) return;
    s.done = true;
    s.doneReason = reason;
    s.intro?.pause();
    s.host?.remove();
    s.host = null;
    resume(s);
  }

  function showIntro(s) {
    const player = document.getElementById("movie_player");
    if (!player || s.host || session !== s) return;
    const source = sourceVideo();
    const host = document.createElement("div");
    host.style.cssText = "position:absolute;inset:0;z-index:2147483647;display:block;";
    const root = host.attachShadow({ mode: "closed" });
    root.innerHTML = `
      <style>
        :host { color-scheme: dark; }
        .screen { position:absolute;inset:0;background:#000;color:#fff;font:14px system-ui,sans-serif; }
        video { width:100%;height:100%;object-fit:contain; }
        .bar { position:absolute;top:16px;left:16px;right:16px;display:flex;align-items:center;justify-content:space-between;gap:12px;pointer-events:none; }
        span { padding:8px 12px;background:#000b;border-radius:6px; }
        button { color:#fff;background:#202020;border:1px solid #ffffff70;border-radius:6px;padding:10px 16px;cursor:pointer;font:inherit;pointer-events:auto; }
        button:focus-visible { outline:3px solid #fff;outline-offset:3px; }
        .start { position:absolute;left:50%;top:50%;transform:translate(-50%,-50%); }
        [hidden] { display:none; }
      </style>
      <section class="screen" aria-label="อินโทรก่อนวิดีโอ RUBSARB">
        <video controls playsinline aria-label="WHATEVER INTRO"></video>
        <div class="bar"><span>RUBSARB WHATEVER - intro</span><button class="skip" type="button">ข้ามอินโทร</button></div>
        <button class="start" type="button" hidden>▶ เล่นอินโทร</button>
      </section>`;
    const intro = root.querySelector("video");
    const start = root.querySelector(".start");
    intro.src = chrome.runtime.getURL("media/intro.mp4");
    intro.volume = source?.volume ?? 1;
    intro.muted = source?.muted ?? false;
    s.host = host;
    s.intro = intro;
    // Keep keyboard shortcuts from controlling YouTube behind the overlay.
    host.addEventListener("keydown", event => event.stopPropagation());
    host.addEventListener("click", event => event.stopPropagation());
    root.querySelector(".skip").addEventListener("click", () => finish(s));
    intro.addEventListener("ended", () => finish(s));
    intro.addEventListener("error", () => finish(s));
    async function playIntro() {
      try {
        await intro.play();
        start.hidden = true;
      } catch {
        if (session === s && !s.done) start.hidden = false;
      }
    }
    start.addEventListener("click", playIntro);
    player.append(host);
    void playIntro();
  }

  function tick() {
    syncRoute();
    const s = session;
    if (!s || s.done || s.target === false || settingsFailed || showingAd()) return;
    const video = sourceVideo();
    if (settingsReady && s.target === true && !R.decide(config, s.id, s.title).enabled) {
      finish(s, 'filtered');
      return;
    }
    if (video && !video.paused) {
      s.wantsPlay = true;
      video.pause();
    }
    if (settingsReady && s.target === true && video?.readyState >= 2 && !video.seeking) {
      // Allow only first-frame timing jitter (50 ms), never a resumed position.
      if (hasStartOffset() || video.currentTime > 0.05) {
        finish(s);
        return;
      }
      if (s.wantsPlay) showIntro(s);
    }
    // If YouTube changes its metadata API, release playback instead of trapping it.
    if ((!settingsReady || s.target === null) && Date.now() - s.startedAt > 10000) {
      s.target = false;
      resume(s);
    }
  }

  document.addEventListener("play", event => {
    syncRoute();
    if (event.target !== sourceVideo() || !blocked()) return;
    session.wantsPlay = true;
    event.target.pause();
    tick();
  }, true);

  document.addEventListener("rubsarb-intro:metadata", event => {
    syncRoute();
    const s = session;
    if (!s) return;
    try {
      const data = JSON.parse(event.detail);
      if (data.videoId !== s.id || typeof data.channelId !== "string" || typeof data.title !== 'string' || !data.title.trim()) return;
      if (s.target !== null && s.title === data.title) return;
      s.title = data.title;
      s.target = data.channelId === CHANNEL_ID;
      if (!s.target) resume(s);
      tick();
    } catch { /* Ignore incomplete metadata. */ }
  });

  function settingsChanged() {
    const s = session;
    const video = sourceVideo();
    if (s?.doneReason === 'filtered' && video?.readyState >= 2 && !video.seeking && video.currentTime <= 0.05 && !hasStartOffset()) {
      s.done = false; s.doneReason = null; s.wantsPlay = !video.paused;
    }
    tick();
  }
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    const patch = {};
    for (const key of ['filtersEnabled', 'keywords', 'videoOverrides']) {
      if (changes[key]) patch[key] = changes[key].newValue;
    }
    config = R.normalizeConfig({ ...config, ...patch });
    settingsChanged();
  });
  chrome.runtime.onMessage.addListener((message, _sender, reply) => {
    if (message?.type !== 'rubsarb-intro:status') return;
    syncRoute();
    reply(session ? { id: session.id, title: session.title, target: session.target } : null);
  });
  chrome.storage.local.get(['filtersEnabled', 'keywords', 'videoOverrides']).then(raw => {
    config = R.normalizeConfig(raw); settingsReady = true; tick();
  }).catch(() => {
    // Release the player if Chrome cannot read preferences.
    settingsFailed = true;
    if (session && !session.done) finish(session, 'settings-error');
  });

  document.addEventListener("yt-navigate-finish", tick);
  setInterval(tick, 100);
  syncRoute();
})();
