(() => {
  const R = RubsarbIntro;
  const $ = id => document.getElementById(id);
  let config = R.normalizeConfig();
  let video = null;
  let ready = false;
  let busy = false;
  function status(text, error = false) {
    $('status').textContent = text;
    $('status').classList.toggle('error', error);
  }
  function render() {
    const eligible = ready && video?.target === true;
    $('video-enabled').disabled = !eligible || busy;
    $('filters-enabled').disabled = !ready || busy;
    $('filters-enabled').checked = config.filtersEnabled;
    $('new-keyword').disabled = !ready || busy;
    $('add-keyword').querySelector('button').disabled = !ready || busy;
    $('reset-video').hidden = !eligible || !Object.hasOwn(config.videoOverrides, video.id);
    $('reset-video').disabled = busy;
    $('video-title').textContent = eligible ? video.title : 'เปิดคลิปปกติของช่อง RUBSARB บน YouTube เพื่อเลือกเฉพาะคลิป';
    if (eligible) {
      const rule = R.decide(config, video.id, video.title);
      $('video-enabled').checked = rule.enabled;
      $('video-reason').textContent = rule.reason === 'override'
        ? `ตั้งเฉพาะคลิปนี้: ${rule.enabled ? 'เปิดอินโทร (ไม่ใช้ตัวกรองคำ)' : 'ข้ามอินโทร'}`
        : rule.reason === 'keyword' ? `ข้ามเพราะชื่อคลิปมีคำว่า “${rule.keyword}”` : 'ใช้ตัวกรองอัตโนมัติ: เปิดอินโทร';
    } else { $('video-enabled').checked = false; $('video-reason').textContent = ''; }
    $('keywords').replaceChildren();
    config.keywords.forEach((word, index) => {
      const row = document.createElement('li');
      const label = document.createElement('label');
      const check = document.createElement('input');
      check.type = 'checkbox'; check.checked = word.enabled; check.disabled = !ready || busy;
      check.addEventListener('change', () => save({ keywords: config.keywords.map((item, i) => i === index ? { ...item, enabled: check.checked } : item) }));
      label.append(check, document.createTextNode(word.text));
      const remove = document.createElement('button');
      remove.type = 'button'; remove.textContent = 'ลบ'; remove.disabled = !ready || busy;
      remove.setAttribute('aria-label', `ลบคำ ${word.text}`);
      remove.addEventListener('click', () => save({ keywords: config.keywords.filter((_, i) => i !== index) }));
      row.append(label, remove); $('keywords').append(row);
    });
    if (!config.keywords.length) {
      const empty = document.createElement('li'); empty.textContent = 'ยังไม่มีคำที่ให้ข้าม เพิ่มคำด้านล่างได้เลย'; $('keywords').append(empty);
    }
    $('saved-videos').replaceChildren();
    const overrides = Object.entries(config.videoOverrides);
    $('saved-videos-section').hidden = !overrides.length;
    overrides.forEach(([id, item]) => {
      const row = document.createElement('li');
      const name = document.createElement('span'); name.textContent = `${item.enabled ? 'เปิด' : 'ปิด'} · ${item.title || id}`;
      const remove = document.createElement('button'); remove.type = 'button'; remove.textContent = 'ล้าง'; remove.disabled = busy;
      remove.setAttribute('aria-label', `ล้างการตั้งค่าคลิป ${item.title || id}`);
      remove.addEventListener('click', () => clearVideo(id));
      row.append(name, remove); $('saved-videos').append(row);
    });
  }
  async function save(patch) {
    if (busy || !ready) return;
    busy = true; render(); status('กำลังบันทึก…');
    let succeeded = false;
    try {
      await chrome.storage.local.set(patch);
      config = R.normalizeConfig({ ...config, ...patch });
      succeeded = true; status('บันทึกในเครื่องแล้ว');
    } catch { status('บันทึกไม่สำเร็จ ลองอีกครั้ง', true); }
    finally { busy = false; render(); }
    return succeeded;
  }
  function clearVideo(id) {
    const videoOverrides = { ...config.videoOverrides }; delete videoOverrides[id];
    return save({ videoOverrides });
  }
  $('video-enabled').addEventListener('change', () => {
    if (video?.target !== true) return;
    void save({ videoOverrides: { ...config.videoOverrides, [video.id]: { enabled: $('video-enabled').checked, title: video.title } } });
  });
  $('reset-video').addEventListener('click', () => video && clearVideo(video.id));
  $('filters-enabled').addEventListener('change', () => save({ filtersEnabled: $('filters-enabled').checked }));
  $('add-keyword').addEventListener('submit', async event => {
    event.preventDefault();
    const input = $('new-keyword'); const text = input.value.trim();
    if (!R.normalizeText(text)) { status('ใส่คำที่มีตัวอักษรหรือตัวเลข', true); return; }
    if (config.keywords.some(word => R.normalizeText(word.text) === R.normalizeText(text))) { status('มีคำนี้ในรายการแล้ว', true); return; }
    if (await save({ keywords: [...config.keywords, { text, enabled: true }] })) { input.value = ''; input.focus(); }
  });
  async function refreshVideo() {
    if (busy) return;
    let next = null;
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab?.id) next = await chrome.tabs.sendMessage(tab.id, { type: 'rubsarb-intro:status' });
    } catch { /* Settings remain usable outside YouTube and before a refreshed content script is ready. */ }
    if (JSON.stringify(video) !== JSON.stringify(next)) { video = next; render(); }
  }
  async function init() {
    try {
      config = R.normalizeConfig(await chrome.storage.local.get(['filtersEnabled', 'keywords', 'videoOverrides']));
      ready = true; status('บันทึกการเปลี่ยนแปลงอัตโนมัติ');
    } catch { status('อ่านการตั้งค่าไม่ได้ ปิดแล้วเปิดหน้าต่างนี้ใหม่', true); }
    await refreshVideo();
    render();
    setInterval(refreshVideo, 1000);
  }
  void init();
})();
